import flet as ft
from supabase import create_client
from datetime import datetime, timedelta
import hashlib
import os

# Supabase konfigurace (stejna jako PC verze)
SUPABASE_URL = "https://qdprvityclnzgqglvpao.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFkcHJ2aXR5Y2xuemdxZ2x2cGFvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk2MjQwNDYsImV4cCI6MjA4NTIwMDA0Nn0._NrSS8VYjW8PZ6lGpdNYc5YrhOv2FOKV9hLXxd3ew0o"


class SpojkaCVPMobile:
    def __init__(self, page: ft.Page):
        self.page = page
        self.supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
        self.aktualni_uzivatel = None
        self.aktualni_dokument = None
        self.aktualni_kategorie_id = None

        # Nastaveni stranky
        self.page.title = "SpojkaCVP Mobile"
        self.page.theme_mode = ft.ThemeMode.LIGHT
        self.page.padding = 0

        # Pro mobil
        self.page.window.width = 400
        self.page.window.height = 750

        # Zobraz prihlaseni
        self.zobraz_prihlaseni()

    # === HESLA ===
    def _hash_hesla(self, heslo, sul=None):
        if sul is None:
            sul = os.urandom(32)
        else:
            sul = bytes.fromhex(sul)
        hash_obj = hashlib.pbkdf2_hmac('sha256', heslo.encode('utf-8'), sul, 100000)
        return sul.hex() + ':' + hash_obj.hex()

    def _over_heslo(self, heslo, ulozeny_hash):
        sul, hash_hodnota = ulozeny_hash.split(':')
        novy_hash = self._hash_hesla(heslo, sul)
        return novy_hash == ulozeny_hash

    # === PRIHLASENI ===
    def zobraz_prihlaseni(self):
        self.page.clean()

        # Zkontroluj jestli existuji uzivatele
        result = self.supabase.table('uzivatele').select('id').limit(1).execute()
        existuji_uzivatele = len(result.data) > 0

        jmeno_field = ft.TextField(
            label="Uživatelské jméno",
            prefix_icon=ft.Icons.PERSON,
            width=300
        )
        heslo_field = ft.TextField(
            label="Heslo",
            password=True,
            can_reveal_password=True,
            prefix_icon=ft.Icons.LOCK,
            width=300
        )

        chyba_text = ft.Text("", color=ft.Colors.RED, size=14)

        rezim_registrace = not existuji_uzivatele

        titulek = ft.Text(
            "Vytvořte prvního admina" if not existuji_uzivatele else "Přihlášení",
            size=24,
            weight=ft.FontWeight.BOLD
        )

        def prepni_rezim(e):
            nonlocal rezim_registrace
            rezim_registrace = not rezim_registrace
            titulek.value = "Registrace" if rezim_registrace else "Přihlášení"
            potvrdit_btn.text = "Registrovat" if rezim_registrace else "Přihlásit"
            prepni_btn.text = "Zpět na přihlášení" if rezim_registrace else "Registrace"
            self.page.update()

        def potvrdit(e):
            jmeno = jmeno_field.value.strip()
            heslo = heslo_field.value

            if not jmeno or not heslo:
                chyba_text.value = "Vyplňte jméno a heslo"
                self.page.update()
                return

            if rezim_registrace:
                # Registrace
                if len(jmeno) < 3:
                    chyba_text.value = "Jméno musí mít alespoň 3 znaky"
                    self.page.update()
                    return
                if len(heslo) < 4:
                    chyba_text.value = "Heslo musí mít alespoň 4 znaky"
                    self.page.update()
                    return

                # Zkontroluj jestli uzivatel existuje
                result = self.supabase.table('uzivatele').select('id').eq('jmeno', jmeno).execute()
                if result.data:
                    chyba_text.value = "Uživatel již existuje"
                    self.page.update()
                    return

                # Vytvor uzivatele
                heslo_hash = self._hash_hesla(heslo)
                role = 'admin' if not existuji_uzivatele else 'uzivatel'

                try:
                    result = self.supabase.table('uzivatele').insert({
                        'jmeno': jmeno,
                        'heslo_hash': heslo_hash,
                        'role': role
                    }).execute()

                    if result.data:
                        chyba_text.value = ""
                        chyba_text.color = ft.Colors.GREEN
                        chyba_text.value = "Registrace úspěšná! Můžete se přihlásit."
                        self.page.update()
                except Exception as ex:
                    chyba_text.value = f"Chyba: {ex}"
                    self.page.update()
            else:
                # Prihlaseni
                result = self.supabase.table('uzivatele').select('*').eq('jmeno', jmeno).execute()

                if not result.data:
                    chyba_text.value = "Uživatel neexistuje"
                    self.page.update()
                    return

                uzivatel = result.data[0]

                if self._over_heslo(heslo, uzivatel['heslo_hash']):
                    self.aktualni_uzivatel = {
                        'id': uzivatel['id'],
                        'jmeno': uzivatel['jmeno'],
                        'role': uzivatel['role']
                    }
                    # Nastav online status
                    self._nastav_online()
                    self.zobraz_hlavni()
                else:
                    chyba_text.value = "Špatné heslo"
                    self.page.update()

        potvrdit_btn = ft.Button(
            "Vytvořit admina" if not existuji_uzivatele else "Přihlásit",
            icon=ft.Icons.LOGIN,
            on_click=potvrdit,
            width=300,
            height=50
        )

        prepni_btn = ft.TextButton(
            "Registrace" if existuji_uzivatele else "",
            on_click=prepni_rezim,
            visible=existuji_uzivatele
        )

        self.page.add(
            ft.Container(
                content=ft.Column([
                    ft.Container(height=80),
                    ft.Icon(ft.Icons.DESCRIPTION, size=80, color=ft.Colors.BLUE),
                    ft.Text("SpojkaCVP", size=32, weight=ft.FontWeight.BOLD),
                    ft.Text("Mobile", size=16, color=ft.Colors.GREY),
                    ft.Container(height=30),
                    titulek,
                    ft.Container(height=10),
                    jmeno_field,
                    heslo_field,
                    chyba_text,
                    ft.Container(height=10),
                    potvrdit_btn,
                    prepni_btn,
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                padding=20,
                expand=True
            )
        )

    def _nastav_online(self):
        try:
            self.supabase.table('online_uzivatele').upsert({
                'uzivatel_id': self.aktualni_uzivatel['id'],
                'posledni_aktivita': datetime.now().isoformat()
            }, on_conflict='uzivatel_id').execute()
        except:
            pass

    # === HLAVNI OBRAZOVKA ===
    def zobraz_hlavni(self):
        self.page.clean()

        # AppBar
        self.page.appbar = ft.AppBar(
            leading=ft.Icon(ft.Icons.DESCRIPTION),
            title=ft.Text("SpojkaCVP"),
            center_title=False,
            bgcolor=ft.Colors.BLUE,
            actions=[
                ft.IconButton(ft.Icons.CHAT, on_click=lambda e: self.zobraz_chat(), tooltip="Chat"),
                ft.IconButton(ft.Icons.LOGOUT, on_click=lambda e: self.odhlasit(), tooltip="Odhlásit"),
            ]
        )

        # Bottom navigation
        self.page.navigation_bar = ft.NavigationBar(
            destinations=[
                ft.NavigationBarDestination(icon=ft.Icons.FOLDER, label="Kategorie"),
                ft.NavigationBarDestination(icon=ft.Icons.ARTICLE, label="Dokumenty"),
                ft.NavigationBarDestination(icon=ft.Icons.SEARCH, label="Hledat"),
            ],
            on_change=self._zmen_tab
        )

        # Hlavni obsah
        self.hlavni_obsah = ft.Container(expand=True)
        self.page.add(self.hlavni_obsah)

        # Zobraz kategorie jako vychozi
        self._zobraz_kategorie()

    def _zmen_tab(self, e):
        index = e.control.selected_index
        if index == 0:
            self._zobraz_kategorie()
        elif index == 1:
            self._zobraz_dokumenty()
        elif index == 2:
            self._zobraz_hledani()

    # === KATEGORIE ===
    def _zobraz_kategorie(self):
        result = self.supabase.table('kategorie').select('*').order('nazev').execute()
        kategorie = result.data

        def vyber_kategorii(kat_id):
            self.aktualni_kategorie_id = kat_id
            self.page.navigation_bar.selected_index = 1
            self._zobraz_dokumenty()
            self.page.update()

        def nova_kategorie(e):
            def ulozit(e):
                nazev = nazev_field.value.strip()
                if nazev:
                    self.supabase.table('kategorie').insert({
                        'nazev': nazev,
                        'vlastnik_id': self.aktualni_uzivatel['id']
                    }).execute()
                    dialog.open = False
                    self.page.update()
                    self._zobraz_kategorie()

            nazev_field = ft.TextField(label="Název kategorie", autofocus=True)
            dialog = ft.AlertDialog(
                title=ft.Text("Nová kategorie"),
                content=nazev_field,
                actions=[
                    ft.TextButton("Zrušit", on_click=lambda e: self._zavrit_dialog(dialog)),
                    ft.Button("Vytvořit", on_click=ulozit),
                ]
            )
            self.page.overlay.append(dialog)
            dialog.open = True
            self.page.update()

        seznam = []
        for kat in kategorie:
            seznam.append(
                ft.Card(
                    content=ft.Container(
                        content=ft.ListTile(
                            leading=ft.Icon(ft.Icons.FOLDER, color=kat.get('barva', '#3498db')),
                            title=ft.Text(kat['nazev'], weight=ft.FontWeight.BOLD),
                            subtitle=ft.Text(kat.get('popis', '') or ""),
                            on_click=lambda e, kid=kat['id']: vyber_kategorii(kid),
                        ),
                        padding=5
                    )
                )
            )

        self.hlavni_obsah.content = ft.Column([
            ft.Container(
                content=ft.Row([
                    ft.Text("Kategorie", size=20, weight=ft.FontWeight.BOLD),
                    ft.IconButton(ft.Icons.ADD, on_click=nova_kategorie, tooltip="Nová kategorie"),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                padding=10
            ),
            ft.Container(
                content=ft.Column(seznam, scroll=ft.ScrollMode.AUTO, spacing=5) if seznam else
                    ft.Text("Žádné kategorie. Vytvořte první!", italic=True),
                expand=True,
                padding=10
            )
        ], expand=True)
        self.page.update()

    def _zavrit_dialog(self, dialog):
        dialog.open = False
        self.page.update()

    # === DOKUMENTY ===
    def _zobraz_dokumenty(self):
        query = self.supabase.table('dokumenty').select('*, kategorie(nazev)')
        if self.aktualni_kategorie_id:
            query = query.eq('kategorie_id', self.aktualni_kategorie_id)
        result = query.order('upraveno', desc=True).execute()
        dokumenty = result.data

        def otevri_dokument(dok):
            self.aktualni_dokument = dok
            self._zobraz_detail_dokumentu()

        def novy_dokument(e):
            def ulozit(e):
                nazev = nazev_field.value.strip()
                if nazev:
                    self.supabase.table('dokumenty').insert({
                        'nazev': nazev,
                        'obsah': '',
                        'typ_souboru': 'txt',
                        'kategorie_id': self.aktualni_kategorie_id,
                        'vlastnik_id': self.aktualni_uzivatel['id'],
                        'pocet_radku': 0,
                        'velikost': 0
                    }).execute()
                    dialog.open = False
                    self.page.update()
                    self._zobraz_dokumenty()

            nazev_field = ft.TextField(label="Název dokumentu", autofocus=True)
            dialog = ft.AlertDialog(
                title=ft.Text("Nový dokument"),
                content=nazev_field,
                actions=[
                    ft.TextButton("Zrušit", on_click=lambda e: self._zavrit_dialog(dialog)),
                    ft.Button("Vytvořit", on_click=ulozit),
                ]
            )
            self.page.overlay.append(dialog)
            dialog.open = True
            self.page.update()

        seznam = []
        for dok in dokumenty:
            kat_nazev = ""
            if dok.get('kategorie') and isinstance(dok['kategorie'], dict):
                kat_nazev = dok['kategorie'].get('nazev', '')

            seznam.append(
                ft.Card(
                    content=ft.Container(
                        content=ft.ListTile(
                            leading=ft.Icon(ft.Icons.ARTICLE),
                            title=ft.Text(dok['nazev'] or "Bez názvu", weight=ft.FontWeight.BOLD),
                            subtitle=ft.Text(f"{kat_nazev} • {dok.get('pocet_radku', 0)} řádků"),
                            trailing=ft.Text(dok.get('typ_souboru', 'txt'), size=12),
                            on_click=lambda e, d=dok: otevri_dokument(d),
                        ),
                        padding=5
                    )
                )
            )

        filtr_text = ""
        if self.aktualni_kategorie_id:
            # Najdi nazev kategorie
            for dok in dokumenty:
                if dok.get('kategorie'):
                    filtr_text = f" ({dok['kategorie'].get('nazev', '')})"
                    break

        self.hlavni_obsah.content = ft.Column([
            ft.Container(
                content=ft.Row([
                    ft.Row([
                        ft.Text(f"Dokumenty{filtr_text}", size=20, weight=ft.FontWeight.BOLD),
                        ft.IconButton(
                            ft.Icons.CLEAR,
                            on_click=lambda e: self._zrus_filtr(),
                            tooltip="Zobrazit vše",
                            visible=self.aktualni_kategorie_id is not None
                        ) if self.aktualni_kategorie_id else ft.Container(),
                    ]),
                    ft.IconButton(ft.Icons.ADD, on_click=novy_dokument, tooltip="Nový dokument"),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                padding=10
            ),
            ft.Container(
                content=ft.Column(seznam, scroll=ft.ScrollMode.AUTO, spacing=5) if seznam else
                    ft.Text("Žádné dokumenty.", italic=True),
                expand=True,
                padding=10
            )
        ], expand=True)
        self.page.update()

    def _zrus_filtr(self):
        self.aktualni_kategorie_id = None
        self._zobraz_dokumenty()

    # === DETAIL DOKUMENTU ===
    def _zobraz_detail_dokumentu(self):
        dok = self.aktualni_dokument
        if not dok:
            return

        obsah_field = ft.TextField(
            value=dok.get('obsah', '') or '',
            multiline=True,
            min_lines=15,
            max_lines=20,
            expand=True
        )

        def ulozit(e):
            novy_obsah = obsah_field.value
            pocet_radku = len(novy_obsah.split('\n')) if novy_obsah else 0
            velikost = len(novy_obsah.encode('utf-8')) if novy_obsah else 0

            self.supabase.table('dokumenty').update({
                'obsah': novy_obsah,
                'pocet_radku': pocet_radku,
                'velikost': velikost,
                'upraveno': datetime.now().isoformat()
            }).eq('id', dok['id']).execute()

            # Zobraz potvrzeni
            self.page.snack_bar = ft.SnackBar(ft.Text("Dokument uložen!"), bgcolor=ft.Colors.GREEN)
            self.page.snack_bar.open = True
            self.page.update()

        def smazat(e):
            def potvrdit_smazani(e):
                self.supabase.table('dokumenty').delete().eq('id', dok['id']).execute()
                dialog.open = False
                self.aktualni_dokument = None
                self._zobraz_dokumenty()
                self.page.update()

            dialog = ft.AlertDialog(
                title=ft.Text("Smazat dokument?"),
                content=ft.Text(f"Opravdu smazat '{dok['nazev']}'?"),
                actions=[
                    ft.TextButton("Zrušit", on_click=lambda e: self._zavrit_dialog(dialog)),
                    ft.Button("Smazat", on_click=potvrdit_smazani, bgcolor=ft.Colors.RED),
                ]
            )
            self.page.overlay.append(dialog)
            dialog.open = True
            self.page.update()

        def zpet(e):
            self.aktualni_dokument = None
            self._zobraz_dokumenty()

        # Statistiky
        obsah = dok.get('obsah', '') or ''
        radky = len(obsah.split('\n'))
        slova = len(obsah.split())
        znaky = len(obsah)

        self.hlavni_obsah.content = ft.Column([
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, on_click=zpet),
                    ft.Text(dok['nazev'] or "Bez názvu", size=18, weight=ft.FontWeight.BOLD, expand=True),
                    ft.IconButton(ft.Icons.DELETE, on_click=smazat, icon_color=ft.Colors.RED),
                ]),
                padding=10
            ),
            ft.Container(
                content=ft.Text(f"Řádků: {radky} | Slov: {slova} | Znaků: {znaky}", size=12, color=ft.Colors.GREY),
                padding=ft.Padding.only(left=10, right=10, bottom=5)
            ),
            ft.Container(
                content=obsah_field,
                expand=True,
                padding=10
            ),
            ft.Container(
                content=ft.Row([
                    ft.Button("Uložit změny", icon=ft.Icons.SAVE, on_click=ulozit, expand=True),
                ]),
                padding=10
            )
        ], expand=True)
        self.page.update()

    # === HLEDANI ===
    def _zobraz_hledani(self):
        hledat_field = ft.TextField(
            label="Hledat v dokumentech...",
            prefix_icon=ft.Icons.SEARCH,
            on_submit=lambda e: hledej()
        )

        vysledky_column = ft.Column(scroll=ft.ScrollMode.AUTO, spacing=5)

        def hledej():
            text = hledat_field.value.strip()
            if not text:
                return

            # Hledej v nazvu a obsahu
            result1 = self.supabase.table('dokumenty').select('*, kategorie(nazev)').ilike('nazev', f'%{text}%').execute()
            result2 = self.supabase.table('dokumenty').select('*, kategorie(nazev)').ilike('obsah', f'%{text}%').execute()

            # Spoj vysledky
            vsechny = {d['id']: d for d in result1.data}
            for d in result2.data:
                vsechny[d['id']] = d

            vysledky_column.controls.clear()

            if not vsechny:
                vysledky_column.controls.append(ft.Text("Nic nenalezeno", italic=True))
            else:
                for dok in vsechny.values():
                    kat_nazev = ""
                    if dok.get('kategorie') and isinstance(dok['kategorie'], dict):
                        kat_nazev = dok['kategorie'].get('nazev', '')

                    vysledky_column.controls.append(
                        ft.Card(
                            content=ft.Container(
                                content=ft.ListTile(
                                    leading=ft.Icon(ft.Icons.ARTICLE),
                                    title=ft.Text(dok['nazev'] or "Bez názvu"),
                                    subtitle=ft.Text(kat_nazev),
                                    on_click=lambda e, d=dok: self._otevri_z_hledani(d),
                                ),
                                padding=5
                            )
                        )
                    )

            self.page.update()

        self.hlavni_obsah.content = ft.Column([
            ft.Container(
                content=ft.Text("Vyhledávání", size=20, weight=ft.FontWeight.BOLD),
                padding=10
            ),
            ft.Container(
                content=ft.Row([
                    ft.Container(content=hledat_field, expand=True),
                    ft.IconButton(ft.Icons.SEARCH, on_click=lambda e: hledej()),
                ]),
                padding=10
            ),
            ft.Container(
                content=vysledky_column,
                expand=True,
                padding=10
            )
        ], expand=True)
        self.page.update()

    def _otevri_z_hledani(self, dok):
        self.aktualni_dokument = dok
        self._zobraz_detail_dokumentu()

    # === CHAT ===
    def zobraz_chat(self):
        self.page.clean()

        # AppBar pro chat
        self.page.appbar = ft.AppBar(
            leading=ft.IconButton(ft.Icons.ARROW_BACK, on_click=lambda e: self.zobraz_hlavni()),
            title=ft.Text("Chat"),
            bgcolor=ft.Colors.BLUE,
        )
        self.page.navigation_bar = None

        chat_column = ft.Column(scroll=ft.ScrollMode.AUTO, expand=True, spacing=5)
        online_row = ft.Row(wrap=True, spacing=5)
        zprava_field = ft.TextField(
            hint_text="Napište zprávu...",
            expand=True,
            on_submit=lambda e: odeslat()
        )

        def nacti_chat():
            # Online uzivatele
            cas_limit = (datetime.now() - timedelta(seconds=60)).isoformat()
            online_result = self.supabase.table('online_uzivatele').select('*, uzivatele(jmeno)').gte('posledni_aktivita', cas_limit).execute()

            online_row.controls.clear()
            for u in online_result.data:
                jmeno = u.get('uzivatele', {}).get('jmeno', 'Neznámý') if u.get('uzivatele') else 'Neznámý'
                online_row.controls.append(
                    ft.Chip(
                        label=ft.Text(jmeno, size=12),
                        leading=ft.Icon(ft.Icons.CIRCLE, color=ft.Colors.GREEN, size=10),
                    )
                )

            # Zpravy
            zpravy_result = self.supabase.table('chat_zpravy').select('*, uzivatele(jmeno)').order('vytvoreno', desc=False).limit(50).execute()

            chat_column.controls.clear()
            for z in zpravy_result.data:
                jmeno = z.get('uzivatele', {}).get('jmeno', 'Neznámý') if z.get('uzivatele') else 'Neznámý'
                cas = str(z.get('vytvoreno', ''))[:16]
                je_moje = z.get('uzivatel_id') == self.aktualni_uzivatel['id']

                chat_column.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text(f"{jmeno} • {cas}", size=10, color=ft.Colors.GREY),
                            ft.Text(z.get('zprava', ''), size=14),
                        ], spacing=2),
                        bgcolor=ft.Colors.BLUE_50 if je_moje else ft.Colors.GREY_100,
                        padding=10,
                        border_radius=10,
                        alignment=ft.alignment.center_right if je_moje else ft.alignment.center_left,
                    )
                )

            self.page.update()

        def odeslat():
            text = zprava_field.value.strip()
            if text:
                self.supabase.table('chat_zpravy').insert({
                    'uzivatel_id': self.aktualni_uzivatel['id'],
                    'zprava': text
                }).execute()
                zprava_field.value = ""
                nacti_chat()

        def obnovit(e):
            self._nastav_online()
            nacti_chat()

        self.page.add(
            ft.Column([
                ft.Container(
                    content=ft.Column([
                        ft.Text("Online uživatelé", size=12, weight=ft.FontWeight.BOLD),
                        online_row,
                    ]),
                    padding=10,
                    bgcolor=ft.Colors.GREY_100,
                ),
                ft.Container(
                    content=chat_column,
                    expand=True,
                    padding=10,
                ),
                ft.Container(
                    content=ft.Row([
                        zprava_field,
                        ft.IconButton(ft.Icons.REFRESH, on_click=obnovit, tooltip="Obnovit"),
                        ft.IconButton(ft.Icons.SEND, on_click=lambda e: odeslat()),
                    ]),
                    padding=10,
                )
            ], expand=True)
        )

        nacti_chat()

    def odhlasit(self):
        try:
            self.supabase.table('online_uzivatele').delete().eq('uzivatel_id', self.aktualni_uzivatel['id']).execute()
        except:
            pass
        self.aktualni_uzivatel = None
        self.page.appbar = None
        self.page.navigation_bar = None
        self.zobraz_prihlaseni()


def main(page: ft.Page):
    app = SpojkaCVPMobile(page)


if __name__ == "__main__":
    ft.app(main)
