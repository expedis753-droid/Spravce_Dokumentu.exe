import flet as ft

def main(page: ft.Page):
    # Nastavení okna
    page.title = "SpojkaCVP Mobile - TEST"
    page.window.width = 400
    page.window.height = 700

    # Testovací obsah
    page.add(
        ft.Column([
            ft.Text("Ahoj! Flet funguje!", size=24, weight=ft.FontWeight.BOLD),
            ft.Text("Toto bude mobilní verze SpojkaCVP"),
            ft.ElevatedButton("Klikni na mě", on_click=lambda e: print("Kliknuto!")),
        ], alignment=ft.MainAxisAlignment.CENTER)
    )

# Spuštění aplikace
ft.app(target=main)
