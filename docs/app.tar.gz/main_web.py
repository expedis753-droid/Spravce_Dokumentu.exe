import flet as ft
import urllib.request
import urllib.parse
import json
import hashlib
import os
from datetime import datetime, timedelta

# Supabase konfigurace
SUPABASE_URL = "https://qdprvityclnzgqglvpao.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFkcHJ2aXR5Y2xuemdxZ2x2cGFvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk2MjQwNDYsImV4cCI6MjA4NTIwMDA0Nn0._NrSS8VYjW8PZ6lGpdNYc5YrhOv2FOKV9hLXxd3ew0o"


class SupabaseWeb:
    """Jednoduchy Supabase klient pro web (bez zavislosti)"""

    def __init__(self):
        self.headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }

    def _request(self, method, endpoint, data=None, params=None):
        url = f"{SUPABASE_URL}/rest/v1/{endpoint}"
        if params:
            url += "?" + urllib.parse.urlencode(params)

        body = json.dumps(data).encode('utf-8') if data else None
        req = urllib.request.Request(url, data=body, headers=self.headers, method=method)

        try:
            with urllib.request.urlopen(req) as response:
                result = response.read().decode('utf-8')
                return json.loads(result) if result else []
        except urllib.error.HTTPError as e:
            print(f"HTTP Error: {e.code} - {e.read().decode()}")
            return []
        except Exception as e:
            print(f"Error: {e}")
            return []

    def select(self, table, columns="*", filters=None, order=None, limit=None):
        params = {"select": columns}
        if filters:
            params.update(filters)
        if order:
            params["order"] = order
        if limit:
            params["limit"] = str(limit)
        return self._request("GET", table, params=params)

    def insert(self, table, data):
        return self._request("POST", table, data=data)

    def update(self, table, data, filters):
        params = filters
        return self._request("PATCH", table, data=data, params=params)

    def delete(self, table, filters):
        return self._request("DELETE", table, params=filters)


class SpojkaCVPMobile:
    def __init__(self, page: ft.Page):
        self.page = page
        self.db = SupabaseWeb()
        self.aktualni_uzivatel = None
        self.aktualni_dokument = None
        self.aktualni_kategorie_id = None

        # Nastaveni stranky
        self.page.title = "SpojkaCVP Mobile"
        self.page.theme_mode = ft.ThemeMode.LIGHT
        self.page.padding = 0

        # Zobraz prihlaseni
        self.zobraz_prihlaseni()

    # === HESLA ===
    def _hash_hesla(self, heslo, sul=None):
        if sul is None:
            sul = os.urandom(32)
        else:
            sul = bytes.fromhex(sul)
        hash_obj = hashlib.pbkdf2_hmac('sha256', heslo.encode('utf-8'), sul, 100000)
        return sul.hex() + ':' + hash_obj.hex()

    def _over_heslo(self, heslo, ulozeny_hash):
        try:
            sul, hash_hodnota = ulozeny_hash.split(':')
            novy_hash = self._hash_hesla(heslo, sul)
            return novy_hash == ulozeny_hash
        except:
            return False

    # === PRIHLASENI ===
    def zobraz_prihlaseni(self):
        self.page.clean()
        self.page.appbar = None
        self.page.navigation_bar = None

        # Zkontroluj jestli existuji uzivatele
        uzivatele = self.db.select("uzivatele", "id", limit=1)
        existuji_uzivatele = len(uzivatele) > 0

        jmeno_field = ft.TextField(
            label="Uživatelské jméno",
            prefix_icon=ft.Icons.PERSON,
            width=300
        )
        heslo_field = ft.TextField(
            label="Heslo",
            password=True,
            can_reveal_password=True,
            prefix_icon=ft.Icons.LOCK,
            width=300
        )

        chyba_text = ft.Text("", color=ft.Colors.RED, size=14)
        self.rezim_registrace = not existuji_uzivatele

        titulek = ft.Text(
            "Vytvořte prvního admina" if not existuji_uzivatele else "Přihlášení",
            size=24,
            weight=ft.FontWeight.BOLD
        )

        def prepni_rezim(e):
            self.rezim_registrace = not self.rezim_registrace
            titulek.value = "Registrace" if self.rezim_registrace else "Přihlášení"
            potvrdit_btn.text = "Registrovat" if self.rezim_registrace else "Přihlásit"
            prepni_btn.text = "Zpět na přihlášení" if self.rezim_registrace else "Registrace"
            self.page.update()

        def potvrdit(e):
            jmeno = jmeno_field.value.strip() if jmeno_field.value else ""
            heslo = heslo_field.value if heslo_field.value else ""

            if not jmeno or not heslo:
                chyba_text.value = "Vyplňte jméno a heslo"
                self.page.update()
                return

            if self.rezim_registrace:
                if len(jmeno) < 3:
                    chyba_text.value = "Jméno musí mít alespoň 3 znaky"
                    self.page.update()
                    return
                if len(heslo) < 4:
                    chyba_text.value = "Heslo musí mít alespoň 4 znaky"
                    self.page.update()
                    return

                # Zkontroluj jestli uzivatel existuje
                existing = self.db.select("uzivatele", "id", {"jmeno": f"eq.{jmeno}"})
                if existing:
                    chyba_text.value = "Uživatel již existuje"
                    self.page.update()
                    return

                # Vytvor uzivatele
                heslo_hash = self._hash_hesla(heslo)
                role = 'admin' if not existuji_uzivatele else 'uzivatel'

                result = self.db.insert("uzivatele", {
                    'jmeno': jmeno,
                    'heslo_hash': heslo_hash,
                    'role': role
                })

                if result:
                    chyba_text.color = ft.Colors.GREEN
                    chyba_text.value = "Registrace úspěšná!"
                    self.rezim_registrace = False
                    self.page.update()
            else:
                # Prihlaseni
                users = self.db.select("uzivatele", "*", {"jmeno": f"eq.{jmeno}"})

                if not users:
                    chyba_text.value = "Uživatel neexistuje"
                    self.page.update()
                    return

                uzivatel = users[0]

                if self._over_heslo(heslo, uzivatel.get('heslo_hash', '')):
                    self.aktualni_uzivatel = {
                        'id': uzivatel['id'],
                        'jmeno': uzivatel['jmeno'],
                        'role': uzivatel.get('role', 'uzivatel')
                    }
                    self.zobraz_hlavni()
                else:
                    chyba_text.value = "Špatné heslo"
                    self.page.update()

        potvrdit_btn = ft.Button(
            "Vytvořit admina" if not existuji_uzivatele else "Přihlásit",
            icon=ft.Icons.LOGIN,
            on_click=potvrdit,
            width=300,
            height=50
        )

        prepni_btn = ft.TextButton(
            "Registrace" if existuji_uzivatele else "",
            on_click=prepni_rezim,
            visible=existuji_uzivatele
        )

        self.page.add(
            ft.Container(
                content=ft.Column([
                    ft.Container(height=50),
                    ft.Icon(ft.Icons.DESCRIPTION, size=80, color=ft.Colors.BLUE),
                    ft.Text("SpojkaCVP", size=32, weight=ft.FontWeight.BOLD),
                    ft.Text("Mobile Web", size=16, color=ft.Colors.GREY),
                    ft.Container(height=20),
                    titulek,
                    ft.Container(height=10),
                    jmeno_field,
                    heslo_field,
                    chyba_text,
                    ft.Container(height=10),
                    potvrdit_btn,
                    prepni_btn,
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                scroll=ft.ScrollMode.AUTO
                ),
                padding=20,
                expand=True
            )
        )

    # === HLAVNI OBRAZOVKA ===
    def zobraz_hlavni(self):
        self.page.clean()

        self.page.appbar = ft.AppBar(
            leading=ft.Icon(ft.Icons.DESCRIPTION),
            title=ft.Text("SpojkaCVP"),
            center_title=False,
            bgcolor=ft.Colors.BLUE,
            actions=[
                ft.IconButton(ft.Icons.CHAT, on_click=lambda e: self.zobraz_chat(), tooltip="Chat"),
                ft.IconButton(ft.Icons.LOGOUT, on_click=lambda e: self.odhlasit(), tooltip="Odhlásit"),
            ]
        )

        self.page.navigation_bar = ft.NavigationBar(
            destinations=[
                ft.NavigationBarDestination(icon=ft.Icons.FOLDER, label="Kategorie"),
                ft.NavigationBarDestination(icon=ft.Icons.ARTICLE, label="Dokumenty"),
                ft.NavigationBarDestination(icon=ft.Icons.SEARCH, label="Hledat"),
            ],
            on_change=self._zmen_tab
        )

        self.hlavni_obsah = ft.Container(expand=True)
        self.page.add(self.hlavni_obsah)
        self._zobraz_kategorie()

    def _zmen_tab(self, e):
        index = e.control.selected_index
        if index == 0:
            self._zobraz_kategorie()
        elif index == 1:
            self._zobraz_dokumenty()
        elif index == 2:
            self._zobraz_hledani()

    # === KATEGORIE ===
    def _zobraz_kategorie(self):
        kategorie = self.db.select("kategorie", "*", order="nazev")

        def vyber_kategorii(kat_id):
            self.aktualni_kategorie_id = kat_id
            self.page.navigation_bar.selected_index = 1
            self._zobraz_dokumenty()
            self.page.update()

        def nova_kategorie(e):
            def ulozit(e):
                nazev = nazev_field.value.strip() if nazev_field.value else ""
                if nazev:
                    self.db.insert("kategorie", {
                        'nazev': nazev,
                        'vlastnik_id': self.aktualni_uzivatel['id']
                    })
                    dialog.open = False
                    self.page.update()
                    self._zobraz_kategorie()

            nazev_field = ft.TextField(label="Název kategorie", autofocus=True)
            dialog = ft.AlertDialog(
                title=ft.Text("Nová kategorie"),
                content=nazev_field,
                actions=[
                    ft.TextButton("Zrušit", on_click=lambda e: self._zavrit_dialog(dialog)),
                    ft.Button("Vytvořit", on_click=ulozit),
                ]
            )
            self.page.overlay.append(dialog)
            dialog.open = True
            self.page.update()

        seznam = []
        for kat in kategorie:
            seznam.append(
                ft.Card(
                    content=ft.Container(
                        content=ft.ListTile(
                            leading=ft.Icon(ft.Icons.FOLDER, color=kat.get('barva', '#3498db')),
                            title=ft.Text(kat.get('nazev', ''), weight=ft.FontWeight.BOLD),
                            subtitle=ft.Text(kat.get('popis', '') or ""),
                            on_click=lambda e, kid=kat['id']: vyber_kategorii(kid),
                        ),
                        padding=5
                    )
                )
            )

        self.hlavni_obsah.content = ft.Column([
            ft.Container(
                content=ft.Row([
                    ft.Text("Kategorie", size=20, weight=ft.FontWeight.BOLD),
                    ft.IconButton(ft.Icons.ADD, on_click=nova_kategorie, tooltip="Nová kategorie"),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                padding=10
            ),
            ft.Container(
                content=ft.Column(seznam, scroll=ft.ScrollMode.AUTO, spacing=5) if seznam else
                    ft.Text("Žádné kategorie", italic=True),
                expand=True,
                padding=10
            )
        ], expand=True)
        self.page.update()

    def _zavrit_dialog(self, dialog):
        dialog.open = False
        self.page.update()

    # === DOKUMENTY ===
    def _zobraz_dokumenty(self):
        filters = {}
        if self.aktualni_kategorie_id:
            filters["kategorie_id"] = f"eq.{self.aktualni_kategorie_id}"

        dokumenty = self.db.select("dokumenty", "*", filters, order="upraveno.desc")

        def otevri_dokument(dok):
            self.aktualni_dokument = dok
            self._zobraz_detail_dokumentu()

        def novy_dokument(e):
            def ulozit(e):
                nazev = nazev_field.value.strip() if nazev_field.value else ""
                if nazev:
                    self.db.insert("dokumenty", {
                        'nazev': nazev,
                        'obsah': '',
                        'typ_souboru': 'txt',
                        'kategorie_id': self.aktualni_kategorie_id,
                        'vlastnik_id': self.aktualni_uzivatel['id'],
                        'pocet_radku': 0,
                        'velikost': 0
                    })
                    dialog.open = False
                    self.page.update()
                    self._zobraz_dokumenty()

            nazev_field = ft.TextField(label="Název dokumentu", autofocus=True)
            dialog = ft.AlertDialog(
                title=ft.Text("Nový dokument"),
                content=nazev_field,
                actions=[
                    ft.TextButton("Zrušit", on_click=lambda e: self._zavrit_dialog(dialog)),
                    ft.Button("Vytvořit", on_click=ulozit),
                ]
            )
            self.page.overlay.append(dialog)
            dialog.open = True
            self.page.update()

        seznam = []
        for dok in dokumenty:
            seznam.append(
                ft.Card(
                    content=ft.Container(
                        content=ft.ListTile(
                            leading=ft.Icon(ft.Icons.ARTICLE),
                            title=ft.Text(dok.get('nazev', 'Bez názvu'), weight=ft.FontWeight.BOLD),
                            subtitle=ft.Text(f"{dok.get('pocet_radku', 0)} řádků"),
                            trailing=ft.Text(dok.get('typ_souboru', 'txt'), size=12),
                            on_click=lambda e, d=dok: otevri_dokument(d),
                        ),
                        padding=5
                    )
                )
            )

        self.hlavni_obsah.content = ft.Column([
            ft.Container(
                content=ft.Row([
                    ft.Row([
                        ft.Text("Dokumenty", size=20, weight=ft.FontWeight.BOLD),
                        ft.IconButton(
                            ft.Icons.CLEAR,
                            on_click=lambda e: self._zrus_filtr(),
                            tooltip="Zobrazit vše",
                        ) if self.aktualni_kategorie_id else ft.Container(),
                    ]),
                    ft.IconButton(ft.Icons.ADD, on_click=novy_dokument, tooltip="Nový dokument"),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                padding=10
            ),
            ft.Container(
                content=ft.Column(seznam, scroll=ft.ScrollMode.AUTO, spacing=5) if seznam else
                    ft.Text("Žádné dokumenty", italic=True),
                expand=True,
                padding=10
            )
        ], expand=True)
        self.page.update()

    def _zrus_filtr(self):
        self.aktualni_kategorie_id = None
        self._zobraz_dokumenty()

    # === DETAIL DOKUMENTU ===
    def _zobraz_detail_dokumentu(self):
        dok = self.aktualni_dokument
        if not dok:
            return

        obsah_field = ft.TextField(
            value=dok.get('obsah', '') or '',
            multiline=True,
            min_lines=10,
            max_lines=15,
            expand=True
        )

        def ulozit(e):
            novy_obsah = obsah_field.value or ''
            pocet_radku = len(novy_obsah.split('\n')) if novy_obsah else 0
            velikost = len(novy_obsah.encode('utf-8')) if novy_obsah else 0

            self.db.update("dokumenty", {
                'obsah': novy_obsah,
                'pocet_radku': pocet_radku,
                'velikost': velikost,
                'upraveno': datetime.now().isoformat()
            }, {"id": f"eq.{dok['id']}"})

            self.page.snack_bar = ft.SnackBar(ft.Text("Uloženo!"), bgcolor=ft.Colors.GREEN)
            self.page.snack_bar.open = True
            self.page.update()

        def smazat(e):
            def potvrdit_smazani(e):
                self.db.delete("dokumenty", {"id": f"eq.{dok['id']}"})
                dialog.open = False
                self.aktualni_dokument = None
                self._zobraz_dokumenty()
                self.page.update()

            dialog = ft.AlertDialog(
                title=ft.Text("Smazat?"),
                content=ft.Text(f"Smazat '{dok.get('nazev', '')}'?"),
                actions=[
                    ft.TextButton("Ne", on_click=lambda e: self._zavrit_dialog(dialog)),
                    ft.Button("Ano", on_click=potvrdit_smazani, bgcolor=ft.Colors.RED),
                ]
            )
            self.page.overlay.append(dialog)
            dialog.open = True
            self.page.update()

        def zpet(e):
            self.aktualni_dokument = None
            self._zobraz_dokumenty()

        obsah = dok.get('obsah', '') or ''
        radky = len(obsah.split('\n'))
        slova = len(obsah.split())

        self.hlavni_obsah.content = ft.Column([
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, on_click=zpet),
                    ft.Text(dok.get('nazev', 'Bez názvu'), size=16, weight=ft.FontWeight.BOLD, expand=True),
                    ft.IconButton(ft.Icons.DELETE, on_click=smazat, icon_color=ft.Colors.RED),
                ]),
                padding=10
            ),
            ft.Container(
                content=ft.Text(f"Řádků: {radky} | Slov: {slova}", size=12, color=ft.Colors.GREY),
                padding=ft.Padding(left=10, right=10, top=0, bottom=5)
            ),
            ft.Container(
                content=obsah_field,
                expand=True,
                padding=10
            ),
            ft.Container(
                content=ft.Row([
                    ft.Button("Uložit", icon=ft.Icons.SAVE, on_click=ulozit, expand=True),
                ]),
                padding=10
            )
        ], expand=True)
        self.page.update()

    # === HLEDANI ===
    def _zobraz_hledani(self):
        hledat_field = ft.TextField(
            label="Hledat...",
            prefix_icon=ft.Icons.SEARCH,
        )

        vysledky_column = ft.Column(scroll=ft.ScrollMode.AUTO, spacing=5)

        def hledej(e):
            text = hledat_field.value.strip() if hledat_field.value else ""
            if not text:
                return

            # Jednoduche hledani v nazvu
            dokumenty = self.db.select("dokumenty", "*", {"nazev": f"ilike.%{text}%"})

            vysledky_column.controls.clear()

            if not dokumenty:
                vysledky_column.controls.append(ft.Text("Nic nenalezeno", italic=True))
            else:
                for dok in dokumenty:
                    vysledky_column.controls.append(
                        ft.Card(
                            content=ft.Container(
                                content=ft.ListTile(
                                    leading=ft.Icon(ft.Icons.ARTICLE),
                                    title=ft.Text(dok.get('nazev', 'Bez názvu')),
                                    on_click=lambda e, d=dok: self._otevri_z_hledani(d),
                                ),
                                padding=5
                            )
                        )
                    )

            self.page.update()

        self.hlavni_obsah.content = ft.Column([
            ft.Container(
                content=ft.Text("Vyhledávání", size=20, weight=ft.FontWeight.BOLD),
                padding=10
            ),
            ft.Container(
                content=ft.Row([
                    ft.Container(content=hledat_field, expand=True),
                    ft.IconButton(ft.Icons.SEARCH, on_click=hledej),
                ]),
                padding=10
            ),
            ft.Container(
                content=vysledky_column,
                expand=True,
                padding=10
            )
        ], expand=True)
        self.page.update()

    def _otevri_z_hledani(self, dok):
        self.aktualni_dokument = dok
        self._zobraz_detail_dokumentu()

    # === CHAT ===
    def zobraz_chat(self):
        self.page.clean()

        self.page.appbar = ft.AppBar(
            leading=ft.IconButton(ft.Icons.ARROW_BACK, on_click=lambda e: self.zobraz_hlavni()),
            title=ft.Text("Chat"),
            bgcolor=ft.Colors.BLUE,
        )
        self.page.navigation_bar = None

        chat_column = ft.Column(scroll=ft.ScrollMode.AUTO, expand=True, spacing=5)
        zprava_field = ft.TextField(hint_text="Napište zprávu...", expand=True)

        def nacti_chat():
            zpravy = self.db.select("chat_zpravy", "*, uzivatele(jmeno)", order="vytvoreno", limit=50)

            chat_column.controls.clear()
            for z in zpravy:
                jmeno = "Neznámý"
                if z.get('uzivatele') and isinstance(z['uzivatele'], dict):
                    jmeno = z['uzivatele'].get('jmeno', 'Neznámý')

                cas = str(z.get('vytvoreno', ''))[:16]
                je_moje = z.get('uzivatel_id') == self.aktualni_uzivatel['id']

                chat_column.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text(f"{jmeno} • {cas}", size=10, color=ft.Colors.GREY),
                            ft.Text(z.get('zprava', ''), size=14),
                        ], spacing=2),
                        bgcolor=ft.Colors.BLUE_50 if je_moje else ft.Colors.GREY_100,
                        padding=10,
                        border_radius=10,
                    )
                )
            self.page.update()

        def odeslat(e):
            text = zprava_field.value.strip() if zprava_field.value else ""
            if text:
                self.db.insert("chat_zpravy", {
                    'uzivatel_id': self.aktualni_uzivatel['id'],
                    'zprava': text
                })
                zprava_field.value = ""
                nacti_chat()

        self.page.add(
            ft.Column([
                ft.Container(content=chat_column, expand=True, padding=10),
                ft.Container(
                    content=ft.Row([
                        zprava_field,
                        ft.IconButton(ft.Icons.REFRESH, on_click=lambda e: nacti_chat()),
                        ft.IconButton(ft.Icons.SEND, on_click=odeslat),
                    ]),
                    padding=10,
                )
            ], expand=True)
        )

        nacti_chat()

    def odhlasit(self):
        self.aktualni_uzivatel = None
        self.page.appbar = None
        self.page.navigation_bar = None
        self.zobraz_prihlaseni()


def main(page: ft.Page):
    app = SpojkaCVPMobile(page)


if __name__ == "__main__":
    ft.app(main)
